package com.example.signup_sqlite;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class dashboard extends AppCompatActivity {

    private LinearLayout homeSection, ordersSection, profileSection;
    private Button homeButton, ordersButton, profileButton, logoutButton;
    private TextView userGreeting;
    private ImageView profileImage;

    private DatabaseHelper dbHelper;
    private String loggedInUserEmail; // Assuming user email is stored during login

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Initialize views
        homeSection = findViewById(R.id.homeSection);
        ordersSection = findViewById(R.id.ordersSection);
        profileSection = findViewById(R.id.profileSection);
        homeButton = findViewById(R.id.homeButton);
        ordersButton = findViewById(R.id.ordersButton);
        profileButton = findViewById(R.id.profileButton);
        logoutButton = findViewById(R.id.logoutButton);
        userGreeting = findViewById(R.id.userGreeting);
        profileImage = findViewById(R.id.userImage);

        dbHelper = new DatabaseHelper(this);

        // Assume logged-in user's email is passed to this activity
        loggedInUserEmail = getIntent().getStringExtra("USER_EMAIL"); // Replace with your actual login method

        // Fetch and display the logged-in user's info
        displayUserProfile();

        // Set default visible content (Home)
        showHomeContent();

        // Home button click
        homeButton.setOnClickListener(v -> showHomeContent());

        // Orders button click
        ordersButton.setOnClickListener(v -> showOrdersContent());

        // Profile button click
        profileButton.setOnClickListener(v -> showProfileContent());

        // Log Out button click
        logoutButton.setOnClickListener(v -> logoutUser());
    }

    private void showHomeContent() {
        // Hide all sections
        hideAllSections();
        // Show home section
        homeSection.setVisibility(View.VISIBLE);
    }

    private void showOrdersContent() {
        // Hide all sections
        hideAllSections();
        // Show orders section
        ordersSection.setVisibility(View.VISIBLE);
    }

    private void showProfileContent() {
        // Hide all sections
        hideAllSections();
        // Show profile section
        profileSection.setVisibility(View.VISIBLE);
    }

    private void hideAllSections() {
        homeSection.setVisibility(View.GONE);
        ordersSection.setVisibility(View.GONE);
        profileSection.setVisibility(View.GONE);
    }

    // Fetch the logged-in user's details and display them on the profile screen
    private void displayUserProfile() {
        Cursor cursor = dbHelper.getAllUsers();
        while (cursor.moveToNext()) {
            @SuppressLint("Range") String email = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COL_EMAIL));
            if (email.equals(loggedInUserEmail)) {
                @SuppressLint("Range") String firstName = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COL_FIRSTNAME));
                // Assuming the profile picture is saved as a resource or URL (this needs modification based on your actual implementation)
                userGreeting.setText("Hello " + firstName);

                // Set profile picture (you can modify this to load an actual image URL or drawable)
                profileImage.setImageResource(R.drawable.usericon); // Replace with dynamic image loading logic
            }
        }
        cursor.close();
    }

    // Handle user log out
    private void logoutUser() {
        // Navigate back to LoginActivity (assuming LoginActivity exists)
        Intent intent = new Intent(dashboard.this, admin.class); // Replace with your LoginActivity
        startActivity(intent);
        finish(); // Finish the current activity so the user cannot return to it by pressing back
    }
}
